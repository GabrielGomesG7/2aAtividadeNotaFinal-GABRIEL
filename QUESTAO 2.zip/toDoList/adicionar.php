<?php
$db = new SQLite3('database.db');

if (isset($_POST['descricao'])) {
  $descricao = $_POST['descricao'];

  $stmt = $db->prepare("INSERT INTO tarefas (descricao) VALUES (:descricao)");
  $stmt->bindValue(':descricao', $descricao, SQLITE3_TEXT);
  $stmt->execute();
}

header('Location: index.php');
