<?php
$db = new SQLite3('database.db');

// Cria a tabela se não existir
$db->exec("CREATE TABLE IF NOT EXISTS tarefas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  descricao TEXT NOT NULL,
  concluida INTEGER DEFAULT 0
)");
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>To-Do List</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
    }

    form {
      margin-bottom: 20px;
    }

    ul {
      list-style-type: none;
      padding: 0;
    }

    li {
      background: #f9f9f9;
      padding: 10px;
      margin-bottom: 8px;
      border-radius: 5px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .feito {
      text-decoration: line-through;
      color: gray;
    }

    .acoes a {
      margin-left: 10px;
      text-decoration: none;
      font-size: 18px;
    }

    .descricao {
      flex: 1;
    }
  </style>
</head>
<body>
  <h1>To-Do List</h1>

  <!-- Formulário -->
  <form action="adicionar.php" method="POST">
    <input type="text" name="descricao" required placeholder="Nova tarefa">
    <button type="submit">Adicionar</button>
  </form>

  <h2>Tarefas:</h2>
  <ul>
    <?php
    $res = $db->query("SELECT * FROM tarefas ORDER BY id DESC");
    while ($tarefa = $res->fetchArray()) {
      $classe = $tarefa['concluida'] ? "feito" : "";

      echo "<li>
              <span class='descricao $classe'>{$tarefa['descricao']}</span>
              <span class='acoes'>
                <a href='editar.php?id={$tarefa['id']}'>📝</a>
                <a href='deletar.php?id={$tarefa['id']}' onclick='return confirm(\"Excluir tarefa?\")'>🗑</a>
              </span>
            </li>";
    }
    ?>
  </ul>
</body>
</html>
