<?php
$db = new SQLite3('database.db');

if (isset($_GET['id'])) {
  $id = $_GET['id'];

  $tarefa = $db->querySingle("SELECT descricao FROM tarefas WHERE id = $id", true);

  if ($tarefa):
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Editar Tarefa</title>
</head>
<body>
  <h1>Editar Tarefa</h1>

  <form action="editar.php" method="POST">
    <input type="hidden" name="id" value="<?= $id ?>">
    <input type="text" name="descricao" value="<?= htmlspecialchars($tarefa['descricao']) ?>" required>
    <button type="submit">Salvar</button>
  </form>
</body>
</html>

<?php
  endif;
} elseif (isset($_POST['id']) && isset($_POST['descricao'])) {
  $id = $_POST['id'];
  $descricao = $_POST['descricao'];

  $stmt = $db->prepare("UPDATE tarefas SET descricao = :descricao WHERE id = :id");
  $stmt->bindValue(':descricao', $descricao, SQLITE3_TEXT);
  $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
  $stmt->execute();

  header('Location: index.php');
}
?>
