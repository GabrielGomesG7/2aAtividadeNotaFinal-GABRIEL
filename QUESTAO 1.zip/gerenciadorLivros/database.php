<?php
// Conexão com o banco
$db = new SQLite3('database.db');

// Cria a tabela se não existir
$db->exec("CREATE TABLE IF NOT EXISTS livros (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  titulo TEXT,
  autor TEXT,
  ano_publicacao INTEGER
)");
?>