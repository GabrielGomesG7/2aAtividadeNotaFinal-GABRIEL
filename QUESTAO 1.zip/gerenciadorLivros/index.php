<?php
// Conexão com o banco
$db = new SQLite3('database.db');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Livros</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    form { margin-bottom: 20px; }
    ul { list-style-type: none; padding: 0; }
    li { margin-bottom: 10px; }
    .livro { padding: 10px; background-color: #f9f9f9; border-radius: 5px; }
    .acoes { margin-left: 10px; }
  </style>
</head>
<body>
  <h1>Adicionar Livro</h1>

  <!-- Formulário de cadastro -->
  <form action="adicionar_livro.php" method="POST">
    <input type="text" name="titulo" placeholder="Título" required>
    <input type="text" name="autor" placeholder="Autor" required>
    <input type="number" name="ano" placeholder="Ano de Publicação" required>
    <button type="submit">Cadastrar</button>
  </form>

  <h2>Livros cadastrados:</h2>
  <ul>
    <?php
    // Consulta livros no banco
    $resultado = $db->query("SELECT * FROM livros ORDER BY id DESC");

    // Lista os livros
    while ($livro = $resultado->fetchArray()) {
      echo "<li class='livro'>
              <strong>{$livro['titulo']}</strong> de {$livro['autor']} ({$livro['ano_publicacao']})
              <a class='acoes' href='delete.php?id={$livro['id']}' onclick='return confirm(\"Tem certeza que deseja excluir este livro?\")'>[Excluir]</a>
            </li>";
    }
    ?>
  </ul>
</body>
</html>
