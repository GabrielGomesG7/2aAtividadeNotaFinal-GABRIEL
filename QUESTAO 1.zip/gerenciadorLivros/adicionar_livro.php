<?php
// Conecta ao banco
$db = new SQLite3('database.db');

// Recebe os dados do formulário
$titulo = $_POST['titulo'];
$autor = $_POST['autor'];
$ano = $_POST['ano'];

// Prepara a query para evitar SQL Injection
$stmt = $db->prepare("INSERT INTO livros (titulo, autor, ano_publicacao) VALUES (:titulo, :autor, :ano)");
$stmt->bindValue(':titulo', $titulo, SQLITE3_TEXT);
$stmt->bindValue(':autor', $autor, SQLITE3_TEXT);
$stmt->bindValue(':ano', $ano, SQLITE3_INTEGER);

// Executa o INSERT
$stmt->execute();

// Redireciona para index
header('Location: index.php');
?>
