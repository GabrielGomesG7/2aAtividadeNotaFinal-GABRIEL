<?php
$db = new SQLite3('database.db');

// Verifica se foi passado um ID
if (isset($_GET['id'])) {
  $id = $_GET['id'];

  // Prepara a exclusão com segurança
  $stmt = $db->prepare("DELETE FROM livros WHERE id = :id");
  $stmt->bindValue(':id', $id, SQLITE3_INTEGER);
  $stmt->execute();
}

// Volta para a página principal
header('Location: index.php');
?>
